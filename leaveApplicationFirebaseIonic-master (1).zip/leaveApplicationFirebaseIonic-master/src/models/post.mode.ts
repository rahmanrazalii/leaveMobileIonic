export interface Post {
   dateFrom: string;
   dateTo: string;
   reason: string;
   status: string;
   applicant: string;
}
